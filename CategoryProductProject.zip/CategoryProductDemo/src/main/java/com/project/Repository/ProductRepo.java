package com.project.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Model.Product;

public interface ProductRepo extends JpaRepository<Product, Long> {

}
